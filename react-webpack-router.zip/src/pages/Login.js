import React, { Component } from 'react'

import '../css/user.css'



class Login extends Component {

	render() {
		return(
			<div className="user">
				<h1 className="title">Hello, I am a Login page!</h1>
			</div>	
		) 
	}
}



export default Login 