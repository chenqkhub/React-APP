import React from "react";
import ReactDom from "react-dom";
import HelloWorld from "./react-demo-1";

ReactDom.render(<HelloWorld/>, document.getElementById("react-container"));