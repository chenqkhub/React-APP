import React from "react";
import ReactDom from "react-dom";
import RefsComponent from "./react-demo-10";

ReactDom.render(<RefsComponent/>, document.getElementById("react-container"));