import React from "react";
import ReactDom from "react-dom";
import BindTimesComponent from "./react-demo-11";

ReactDom.render(<BindTimesComponent/>, document.getElementById("react-container"));