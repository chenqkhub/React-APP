import React from "react";
import ReactDom from "react-dom";
import NameTimesComponent from "./react-demo-12";

ReactDom.render(<NameTimesComponent/>, document.getElementById("react-container"));