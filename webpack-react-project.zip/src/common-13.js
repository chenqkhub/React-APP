import React from "react";
import ReactDom from "react-dom";
import CanControlComponent from "./react-demo-13";

ReactDom.render(<CanControlComponent/>, document.getElementById("react-container"));