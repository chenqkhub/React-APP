import React from "react";
import ReactDom from "react-dom";
import NotControlComponent from "./react-demo-14";

ReactDom.render(<NotControlComponent/>, document.getElementById("react-container"));

