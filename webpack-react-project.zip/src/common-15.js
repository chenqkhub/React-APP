import React from "react";
import ReactDom from "react-dom";
import AjaxListComponent from "./react-demo-15";

ReactDom.render(<AjaxListComponent/>, document.getElementById("react-container"));