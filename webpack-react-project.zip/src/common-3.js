import React from "react";
import ReactDom from "react-dom";
import JSXImprove from "./react-demo-3";

ReactDom.render(<JSXImprove/>, document.getElementById("react-container"));