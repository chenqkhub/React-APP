import React from "react";
import ReactDom from "react-dom";
import StateComponent from "./react-demo-4";

ReactDom.render(<StateComponent/>, document.getElementById("react-container"));