import React from "react";
import ReactDom from "react-dom";
import PropsComponent from "./react-demo-5";

ReactDom.render(<PropsComponent myName="不醉怎能入睡"/>, document.getElementById("react-container"));