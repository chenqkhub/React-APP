import React from "react";
import ReactDom from "react-dom";
import CycleComponent from "./react-demo-6";

ReactDom.render(<CycleComponent myName="不醉怎能入睡"/>, document.getElementById("react-container"));