import React from "react";
import ReactDom from "react-dom";
import CycleTwoComponent from "./react-demo-7";

ReactDom.render(<CycleTwoComponent myName="不醉怎能入睡"/>, document.getElementById("react-container"));