import React from "react";
import ReactDom from "react-dom";
import ChildrenComponent from "./react-demo-8";

ReactDom.render(
    <ChildrenComponent>
        <p>坤少</p>
        <p>陈青坤</p>
        <p>不醉怎能入睡</p>
    </ChildrenComponent>,
    document.getElementById("react-container"));