import React from "react";
import ReactDom from "react-dom";
import BindComponent from "./react-demo-9";

ReactDom.render(<BindComponent title="校验规则" children description="this is propType rule"/>, document.getElementById("react-container"));