import React, { Component } from 'react';

class HelloWorld extends Component {
    constructor(props){
        super(props);
        this.state = {};
    }
    render() {
        return React.createElement('h1', null, 'Hello World!');
    }
}

export default HelloWorld;
