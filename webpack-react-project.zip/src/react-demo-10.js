import React, { Component } from 'react';

/*
* */

class RefsComponent extends Component {
    handelClick = () => {
        this.refs.myTextInput.focus();
    }

    render() {
        return (
            <div className="container">
                <input type="text" ref="myTextInput"/>
                <button onClick={this.handelClick}>click me get focus</button>
            </div>
        );
    }
}


export default RefsComponent;