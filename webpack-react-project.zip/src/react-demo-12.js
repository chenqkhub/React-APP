import React, { Component } from 'react';

/*
* */

class NameTimesComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: "",
            checked: false,
            gender: "man",
        }
    }
    handelClick = (event) => {
        const newState = {};
        newState[event.target.name] = event.target.name == "checked" ? event.target.checked : event.target.value;
        this.setState(newState);
        console.log(newState);
    }
    submitHandle = (event) => {
        event.preventDefault();
        const isMan = this.state.checked ? "是" : "否";
        const gender = this.state.gender == "man" ? "男" : "女";
        alert(this.state.username + isMan + gender);
    }

    render() {
        return (
            <div className="panel panel-success">
                <div className="panel-heading">
                    <h3 className="panel-title">答题板</h3>
                </div>
                <div className="panel-body">
                    <form className="form-horizontal" role="form">

                        <div className="form-group">
                            <label htmlFor="username" className="col-sm-2 control-label">姓名</label>
                            <div className="col-sm-6">
                                <input type="text" className="form-control" id="username"
                                       onChange={this.handelClick} name="username"
                                       value={this.state.username} placeholder="请输入名字"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <label htmlFor="checked" className="col-sm-2 control-label">是或者否</label>
                            <div className="col-sm-6">
                                <div className="checkbox">
                                    <label>
                                        <input type="checkbox" name="checked" checked={this.state.checked}
                                               onChange={this.handelClick}/>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label htmlFor="gender" className="col-sm-2 control-label">性别</label>
                            <div className="col-sm-6">
                                <select name="gender" name="gender" onChange={this.handelClick}>
                                    <option value="man">帅哥</option>
                                    <option value="woman">美女</option>
                                </select>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="col-sm-offset-2 col-sm-10">
                                <button type="submit" className="btn btn-default" onClick={this.submitHandle}>查看答案
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}

export default NameTimesComponent;