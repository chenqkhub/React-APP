import React, { Component } from 'react';

/*
* 将input中的value绑定到state的React组件就是可控组件
* 使用onChange事件监听
* */

class CanControlComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            inputValue:""
        }
    }
    handleClick = (event) => {
        this.setState({inputValue:event.target.value});
        console.log(this.state.inputValue);
    }

    render() {
        return (
            <div>
                <input type="text" value={this.state.inputValue} onChange={this.handleClick}/>
            </div>
        );
    }
}

export default CanControlComponent;