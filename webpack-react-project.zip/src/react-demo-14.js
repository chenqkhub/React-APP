import React, { Component } from 'react';
import ReactDom from "react-dom";

/*
* 将input中的value绑定到state的React组件就是可控组件
* 使用onChange事件监听
* */

class NotControlComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            inputValue:""
        }
    }
    handleClick = () => {
        let  value = ReactDom.findDOMNode(this.refs.chenqk).value;
        console.log(value);
    }

    render() {
        return (
            <div>
                <input type="text"  onChange={this.handleClick} ref="chenqk"/>
            </div>
        );
    }
}

export default NotControlComponent;