/**
 * 插件的使用
*/
import React, { Component } from 'react';
class TestComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            <div>
                111111
            </div>
          );
    }
}

export default TestComponent;