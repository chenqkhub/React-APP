import React, { Component } from 'react';
/***
 * 
 * 这里使用了ES6的map方法去遍历数据
 */
let names = ["金庸","古龙","梁羽生"];
class JSXImprove extends  Component{
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render(){
        return(
            <div>
                {
                    names.map((name,i)=>{
                        return <div>{name}</div>
                    })
                }
            </div>
        )
    }
}
export default JSXImprove;