import React, { Component } from 'react';
/*
* statec
* */
class StateComponent extends Component {
    //定义constructor方法，该方法必须继承super方法
    constructor(props) {
        super(props);
        this.state = {enable: false, count: 1};
        //这里不能在一个组件为渲染之前setState，否则会报错
        //this.setState({enable:false});
    }

    //ES6的箭头函数
    handleClick = () => {
        console.info(this.state);
        this.setState({
            enable: !this.state.enable,
            count: this.state.count + 1
        })
    }

    render() {
        return (
            <div>
                <input type="text" disabled={this.state.enable}/>{this.state.count}
                <input type="button" value="click me change" onClick={this.handleClick}/>
            </div>
        )
    }
}

export default StateComponent;