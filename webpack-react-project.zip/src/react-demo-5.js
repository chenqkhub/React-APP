import React, { Component } from 'react';

/*
* */
class PropsComponent extends Component {
    //定义constructor方法，用于state的初始化，该方法必须继承super方法
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() {
        return (
            <div>
                {this.props.myName}
            </div>
        )
    }
}

export default PropsComponent;