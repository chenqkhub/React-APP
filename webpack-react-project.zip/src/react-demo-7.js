import React, { Component } from 'react';

/*
*
* */
class CycleTwoComponent extends Component {
    /**--------------------------------初始化阶段---------------------------------------**/
    //定义constructor方法，用于state的初始化，该方法必须继承super方法
    constructor(props) {
        //ES6的继承机制，实质上会先创建父类的实例对象this，所以这里必须调用super方法
        super(props);
        //这里不能使用setState方法来初始化state的属性
        this.state = {
            opacity: 1
        };

        console.log("init--")
    }

    //render之前被调用(包括更新阶段执行render时)
    static getDerivedStateFromProps(props, state) {
        console.log("上面", props, state);

        return null;
    }

    //render之后被调用
    componentDidMount() {
        console.log("我被初始化了");
        this.timer = setInterval(()=> {
            let opacity = this.state.opacity;
            opacity -= .05;
            console.log(opacity);
            if(opacity < .1){
                opacity = 1;
            }
            this.setState({
                opacity: opacity
            })
        },100);
    }

    /**--------------------------------更新阶段---------------------------------------**/
    //render 之前调用,返回true将重新渲染组件，false将不进行渲染
    shouldComponentUpdate(nextProps, nextState) {
        console.log("在render之前，我将被执行");
        return true;
    }

    //render之后被调用,此时还未更新到真实DOM
    getSnapshotBeforeUpdate(prevProps, prevState) {
        console.log("在render之后，我将被执行");
    }

    //在getSnapshotBeforeUpdate 和componentDidUpdate之间，react开始更新DOM和refs
    //render之后被调用
    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("在render之后，DOM已经被重新渲染");
    }


    /**--------------------------------卸载阶段---------------------------------------**/
    //在这个阶段应该卸载组件，清理数据，清除一些定时器等
    componentWillUnmount() {
        console.log("DOM已经渲染完成，我将被卸载");
        clearInterval(this.timer);
    }

    /**--------------------------------错误处理---------------------------------------**/
    componentDidCatch(error, errorInfo) {
        console.log(error, errorInfo);
    }

    destroyClick() {

    }

    render() {
        return (
            <div style={{opacity:this.state.opacity}}>
                Hello {this.props.myName}
            </div>
        )
    }
}

export default CycleTwoComponent;