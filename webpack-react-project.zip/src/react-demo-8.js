import React, { Component } from 'react';

/*
* 使用ES6+的map方法遍历子节点
* 对于每一个子节点都以return的形式返回
* 父组件与子组件之间使用props传递，且不能更改
* */
class ChildrenComponent extends Component {

    render() {
        return (
            <ol>
                {
                    React.Children.map(this.props.children,(child,i)=>{
                        return <li>{child}</li>
                    })
                }
            </ol>
        )
    }
}

export default ChildrenComponent;