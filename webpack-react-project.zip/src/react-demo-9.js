import React, { Component } from 'react';
import PropTypes from "prop-types";

/*
* */

class PropTypeComponent extends Component {
    render() {
        const {title, description, children} = this.props;

        return (
            <div className="container">
                <h1>{title}</h1>
            </div>
        );
    }
}

PropTypeComponent.propTypes = {
    title:PropTypes.number,
};

export default PropTypeComponent;