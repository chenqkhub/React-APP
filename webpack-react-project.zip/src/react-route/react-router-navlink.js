import React, { Component } from 'react';
import { BrowserRouter as Router, Route, NavLink } from "react-router-dom";
class NavLinkOrLinkComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <ul>
                <li><NavLink exact to="/">Home</NavLink></li>
                <li><NavLink strict
                    to={{
                        pathname: "/user/",
                        state: {isLogin: true},
                        search: 'name=melody',
                        hash: 'tab1'
                    }}>
                    User</NavLink></li>
                <li><NavLink to="/login">Login</NavLink></li>
            </ul>
         );
    }
}
 
export default NavLinkOrLinkComponent;