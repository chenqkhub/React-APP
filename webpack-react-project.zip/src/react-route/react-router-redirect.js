import React, {Component} from 'react';
import {Redirect, Route, Switch} from 'react-router-dom'

class RedirectComponent extends Component {
    render() {
        return (
            <Switch>
                <Redirect from="/hello" to="/user"/>
                <Route path="/login" component={Login}/>
                <Route exact path="/user" render={() => <div>hello user</div>}/>
            </Switch>
        )
    }
}

export default RedirectComponent
