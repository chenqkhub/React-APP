import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
class RouteComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <Router>
                <div>
                    <Route exact path="/" component={Home}/>
                    <Route strict path="/login" render={() => <h1>Login</h1>} />
                    <Route path="/user" children={() => <h1>User</h1>}/>
                </div>
            </Router>
         );
    }
}
 
export default RouteComponent;
