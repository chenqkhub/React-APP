import React, { Component } from 'react';
/***
 * 
 * 这里面最重要的就是需要我们传入的history对象，我前面提到过我们一般不会直接使用<Router>组件，
 * 因为这个组件要求我们手动传入history对象，但这个对象又非常重要，而且不同的开发环境需要不同的history，
 * 所以针对这种情况react-router才衍生了两个插件react-router-dom和react-router-native。
 * 
 */
class Router extends Component {
    //检测接收的参数
    static propTypes = {
      history: PropTypes.object.isRequired, //必须传入
      children: PropTypes.node
    }
  
    //设置传递给子组件的属性
    getChildContext() {
      return {
        router: {
          ...this.context.router, 
          history: this.props.history, //核心对象
          route: {
            location: this.props.history.location, //history里的location对象
            match: this.state.match //当路由路径和当前路径成功匹配，一些有关的路径信息会存放在这里，嵌套路由会用到它。
          }
        }
      }
    }
      state = {
        match: this.computeMatch(this.props.history.location.pathname)
      }
  
    computeMatch(pathname) {
      return {
        path: '/',
        url: '/', 
        params: {}, //页面间传递参数
        isExact: pathname === '/'
      }
    }
  }

class BrowserHashRouterComponent  extends Component {
    constructor(props){
        super(props);
        //createHashHistory.js
        var HashChangeEvent = 'hashchange'; //hash值改变时会触发该事件
        var createHashHistory = function createHashHistory() {
            var globalHistory = window.history; //全局的history对象
            var handleHashChange = function handleHashChange() {} //hash值变化时操作的方法
        }
        //createBrowserHistory.js
        var PopStateEvent = 'popstate'; //监听url的变化事件
        var HashChangeEvent = 'hashchange'; //依然监听了hash改变的事件，但是多加了一个判断是是否需要监听hash改变，如果不需要就不绑定该事件。
        var createBrowserHistory = function createBrowserHistory() {
            var globalHistory = window.history; //全局的history对象
            var handlePop = function handlePop(location) {} //出栈操作
        }

        //createHashHistory.js，createBrowserHistory.js导出的history对象
        const history = {
            length: globalHistory.length, //globalHistory就是window.history
            action: "POP", //操作历史状态都属于出栈操作
            location: initialLocation, //最重要的!!前面的Router.js源码向子组件单独传递了这个对象，因为路由匹配会用到它。
            createHref, //生成的url地址样式，如果是hash则加一个'#'
            push, //扩展history.pushState()方法
            replace, //扩展history.replaceState()方法
            go, //history.go()方法
            goBack, //history.back()方法
            goForward, //history.forward()方法
            block,
            listen
        }
    }
    render(){
        return (
            <div></div>
        )
    }
}