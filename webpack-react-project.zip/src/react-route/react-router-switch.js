import React, { Component } from 'react';
import { BrowserRouter as Router, Route, NavLink,Switch } from "react-router-dom";
class SwitchComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (  
            <Switch>
                    <Route exact path="/dataList" component={List}/>
                    <Route path="/dataList/:id" component={ListDetails}/>
                    <Route path="/error" component={Error} />
                    <Route path="*" render={() => <Redirect to="/error"/> }/>
            </Switch>
        );
    }
}
 
export default SwitchComponent;