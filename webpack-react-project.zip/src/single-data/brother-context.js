import React,{Component} from 'react'
import ReactDom from 'react-dom'
class Brother1 extends React.Component{
    constructor(props){
        super(props);
        this.state = {}
    }

    render(){

        return (
            <div>
                <button onClick={this.context.refresh}>
                    更新兄弟组件
                </button>
            </div>
        )
    }
}
Brother1.contextTypes = {
    refresh: React.PropTypes.any
}
class Brother2 extends React.Component{
    constructor(props){
        super(props);
        this.state = {}
    }

    render(){
        return (
            <div>
                {this.context.text || "兄弟组件未更新"}
            </div>
        )
    }
}
Brother2.contextTypes = {
    text: React.PropTypes.any
}
class Parent extends React.Component{
    constructor(props){
        super(props);
        this.state = {}
    }

    getChildContext(){
        return {
            refresh: this.refresh(),
            text: this.state.text,
        }
    }

    refresh(){
        return (e)=>{
            this.setState({
                text: "兄弟组件沟通成功",
            })
        }
    }
    render(){
        return (
            <div>
                <h2>兄弟组件沟通</h2>
                <Brother1 />
                <Brother2 text={this.state.text}/>
            </div>
        )
    }
}
Parent.childContextTypes = {
    refresh: React.PropTypes.any,
    text: React.PropTypes.any,
}