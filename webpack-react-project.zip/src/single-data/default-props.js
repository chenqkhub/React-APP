import React,{Component} from 'react'
import ReactDom from 'react-dom'
class PropsComponent extends Component{
    constructor(props){
        super(props);
    }
    getDefaultProps(){
        return {
            //这里设置defaultProps
        }
    }
    render(){
        return (
            <div title={this.props.title}></div>
        )
    }
}
PropsComponent.defaultProps = {};
ReactDom.render(<PropsComponent title="test"/>,document.getElementById("react-container"));