import React,{Component} from 'react'
import ReactDom from 'react-dom'
import PropsType from 'prop-types'
class PropsComponent extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return (
            <div title={this.props.title}></div>
        )
    }
}
PropsComponent.PropsType = {
    title: PropsType.string.isRequired
}
ReactDom.render(<PropsComponent title="test"/>,document.getElementById("react-container"));

React.createClass({
    propTypes: {
        // 可以声明 prop 为指定的 JS 基本类型。默认
        // 情况下，这些 prop 都是可传可不传的。
        optionalArray: React.PropTypes.array,
        optionalBool: React.PropTypes.bool,
        optionalFunc: React.PropTypes.func,
        optionalNumber: React.PropTypes.number,
        optionalObject: React.PropTypes.object,
        optionalString: React.PropTypes.string,
        optionalSymbol: React.PropTypes.symbol,

        // 所有可以被渲染的对象：数字，
        // 字符串，DOM 元素或包含这些类型的数组(or fragment) 。
        optionalNode: React.PropTypes.node,

        // React 元素
        optionalElement: React.PropTypes.element,

        // 你同样可以断言一个 prop 是一个类的实例。
        // 用 JS 的 instanceof 操作符声明 prop 为类的实例。
        optionalMessage: React.PropTypes.instanceOf(Message),

        // 你可以用 enum 的方式
        // 确保你的 prop 被限定为指定值。
        optionalEnum: React.PropTypes.oneOf(['News', 'Photos']),

        // 指定的多个对象类型中的一个
        optionalUnion: React.PropTypes.oneOfType([
            React.PropTypes.string,
            React.PropTypes.number,
            React.PropTypes.instanceOf(Message)
        ]),

        // 指定类型组成的数组
        optionalArrayOf: React.PropTypes.arrayOf(React.PropTypes.number),

        // 指定类型的属性构成的对象
        optionalObjectOf: React.PropTypes.objectOf(React.PropTypes.number),

        // 特定形状参数的对象
        optionalObjectWithShape: React.PropTypes.shape({
            color: React.PropTypes.string,
            fontSize: React.PropTypes.number
        }),

        // 你可以在任意东西后面加上 `isRequired`
        // 来确保 如果 prop 没有提供 就会显示一个警告。
        requiredFunc: React.PropTypes.func.isRequired,

        // 不可空的任意类型
        requiredAny: React.PropTypes.any.isRequired,

        // 你可以自定义一个验证器。如果验证失败需要返回一个 Error 对象。
        // 不要直接使用 `console.warn` 或抛异常，
        // 因为这在 `oneOfType` 里不起作用。
        customProp: function(props, propName, componentName) {
            if (!/matchme/.test(props[propName])) {
                return new Error('Validation failed!');
            }
        }
    },
    /* ... */
});