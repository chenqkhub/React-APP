import React,{Component} from 'react'
import ReactDom from 'react-dom'
class PropsComponent extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return (
            <div title={this.props.title}></div>
        )
    }
}
ReactDom.render(<PropsComponent title="test"/>,document.getElementById("react-container"));