import React,{Component} from 'react'
import ReactDom from 'react-dom'
class PropsComponent extends Component{
    constructor(props){
        super(props);
        this.state = {title:"state成员"};
    }
    render(){
        return (
            <div title={this.state.title}></div>
        )
    }
}
ReactDom.render(<PropsComponent/>,document.getElementById("react-container"));