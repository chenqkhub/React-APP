//引入路径
const path = require("path");
//js 压缩插件配置
const uglify = require("uglifyjs-webpack-plugin");
//定义出口文件
module.exports = {
    //配置入口文件
    entry: {
        common1: "./src/common-1.js",
        common2: "./src/common-2.js",
        common3: "./src/common-3.js",
        common4: "./src/common-4.js",
        common5: "./src/common-5.js",
        common6: "./src/common-6.js",
        common7: "./src/common-7.js",
        common8: "./src/common-8.js",
        common9: "./src/common-9.js",
        common10: "./src/common-10.js",
        common11: "./src/common-11.js",
        common12: "./src/common-12.js",
        common13: "./src/common-13.js",
        common14: "./src/common-14.js",
        common15: "./src/common-15.js",
        entry0: "./src/react-demo-0.js",
        entry1: "./src/react-demo-1.js",
        entry2: "./src/react-demo-2.js",
        entry3: "./src/react-demo-3.js",
        entry4: "./src/react-demo-4.js",
        entry5: "./src/react-demo-5.js",
        entry6: "./src/react-demo-6.js",
        entry7: "./src/react-demo-7.js",
        entry8: "./src/react-demo-8.js",
        entry9: "./src/react-demo-9.js",
        entry10: "./src/react-demo-10.js",
        entry11: "./src/react-demo-11.js",
        entry12: "./src/react-demo-12.js",
        entry13: "./src/react-demo-13.js",
        entry14: "./src/react-demo-14.js",
        entry15: "./src/react-demo-15.js",
        parentSon: "./src/single-data/parent-son.js",
        sonSon: "./src/single-data/brother-brother.js"
    },
    //出口文件配置
    output: {
        //输出路径配置
        path: path.resolve("dist/js"),
        filename: "[name].js"
    },
    //模块，解读css文件，图片转换，压缩等
    module: {
        rules: [
            {
                test: "/\.css$/",
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                loaders: ['babel-loader?presets[]=es2015,presets[]=react,presets[]=stage-0']
            },
            {
				test: [/\.gif$/, /\.jpe?g$/, /\.png$/],
				loader: 'url-loader',
				options: {
				  limit: 10000, //该大小以下图片会转成base64
				},
			}
        ]
    },
    //插件，用于生成模板和个性功能
    plugins: [
        new uglify()
    ],
    //配置webpack的开发服务功能
    devServer: {
        //设置基本文件目录
        contentBase: path.resolve("dist"),
        host: "localhost",
        port: 1717
    }
};